/**
 * This is a generated file. Do not edit or your changes will be lost
 */
#import "DkNappSocialModuleAssets.h"

extern NSData* filterDataInRange(NSData* thedata, NSRange range);

@implementation DkNappSocialModuleAssets

- (NSData*) moduleAsset
{
	return nil;
}

@end
